// src/pages/api/paygate/create-payment.js
import { db } from '../../../lib/firebaseAdmin';
import { Timestamp } from 'firebase-admin/firestore';

export default async function handler(req, res) {
  if (req.method !== 'POST') {
    return res.status(405).json({ message: 'Method not allowed' });
  }

  const { username, game, amount, method } = req.body;
  if (!username || !game || !amount || !method) {
    return res.status(400).json({ message: 'Missing required fields.' });
  }

  const yourUsdcWallet = process.env.YOUR_USDC_POLYGON_WALLET;
  if (!yourUsdcWallet) {
    console.error('CRITICAL: YOUR_USDC_POLYGON_WALLET is not set in environment variables.');
    return res.status(500).json({ message: 'Payment provider is not configured.'});
  }

  const orderId = `LUCKYPAWS-${Date.now()}`;
  const successUrl = `${process.env.NEXT_PUBLIC_BASE_URL}/paygate/receipt?orderId=${orderId}`;

  try {
    // In a real integration, you would pass the successUrl to the Paygate.to API.
    // For our simulation, we will use this URL in our response.
    
    // Store the order in Firestore with the success_url
    await db.collection('orders').doc(orderId).set({
      orderId: orderId,
      username,
      game,
      amount: parseFloat(amount),
      method,
      status: 'pending',
      created: Timestamp.now(),
      read: false,
      paymentGateway: 'Paygate',
      success_url: successUrl, // Save the success URL
    });

    // Instead of a generic paymentUrl, we return the specific URL to our receipt page
    res.status(200).json({ receiptUrl: successUrl, orderId: orderId });

  } catch (err) {
    console.error('Paygate payment creation error:', err);
    res.status(500).json({ message: 'Payment creation failed', error: err.message });
  }
}