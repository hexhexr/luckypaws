// src/pages/api/paygate/webhook.js
import { db } from '../../../lib/firebaseAdmin';
import { Timestamp } from 'firebase-admin/firestore';

export default async function handler(req, res) {
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  // It is crucial to verify the webhook signature from Paygate.to
  // This is a simplified example; refer to their documentation for the exact verification steps.
  const signature = req.headers['paygate-signature'];
  const expectedSignature = process.env.PAYGATE_WEBHOOK_SECRET;

  if (!signature || signature !== expectedSignature) {
    console.warn('Unauthorized webhook attempt from Paygate.');
    return res.status(401).json({ error: 'Unauthorized' });
  }

  const { event_type, data } = req.body;
  const orderId = data?.order_id;

  if (!orderId) {
    return res.status(400).json({ error: 'Missing order ID in webhook payload.'});
  }

  const orderRef = db.collection('orders').doc(orderId);

  try {
    if (event_type === 'payment.succeeded') {
      await orderRef.update({
        status: 'paid',
        paidAt: Timestamp.now(),
        read: false, // Mark as unread for the admin dashboard
        transactionId: data?.transaction_id, // Store the transaction ID from Paygate
      });
      console.log(`✅ Order ${orderId} marked as paid via Paygate webhook.`);
    } else if (event_type === 'payment.failed') {
      await orderRef.update({
        status: 'failed',
        failureReason: data?.failure_reason || 'Payment failed as per webhook.',
      });
      console.log(`⚠️ Order ${orderId} marked as failed via Paygate webhook.`);
    }

    res.status(200).json({ success: true });

  } catch (err) {
    console.error(`❌ Firestore update failed for Paygate order ${orderId}:`, err);
    res.status(500).json({ error: 'Failed to update order status.' });
  }
}